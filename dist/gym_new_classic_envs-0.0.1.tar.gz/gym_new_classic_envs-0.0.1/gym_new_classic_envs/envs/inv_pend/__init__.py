"""Custom Inverted Pendulum Environment"""

from gym_new_classic_envs.envs.inv_pend.inv_pend_env import InvertedPendulumEnv