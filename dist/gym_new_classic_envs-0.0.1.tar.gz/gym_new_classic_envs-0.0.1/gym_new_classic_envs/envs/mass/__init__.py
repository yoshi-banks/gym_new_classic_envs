"""Custom Mass-Spring-Damper Environment"""

from gym_new_classic_envs.envs.mass.mass_env import MassEnv