"""Custom BallBeam Environment"""

from gym_new_classic_envs.envs.ballbeam.ballbeam_env import BallbeamEnv