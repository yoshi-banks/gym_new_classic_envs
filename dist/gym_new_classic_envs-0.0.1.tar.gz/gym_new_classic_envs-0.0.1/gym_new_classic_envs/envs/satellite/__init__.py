"""Custom Satellite Environment"""

from gym_new_classic_envs.envs.satellite.satellite_env import SatelliteEnv