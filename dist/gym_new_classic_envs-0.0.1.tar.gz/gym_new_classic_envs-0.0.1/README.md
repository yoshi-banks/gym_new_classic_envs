# gym_new_classic_envs

Final Project for BYU CS 474

Use requirements.txt and conda to create a anaconda environment. `conda create --name <env> --file requirements.txt`. Use a python3.10 environment.

Then run `conda develop .` at the root of this repo to install this module. 

NOTE: only the arm env is currenly working

## Arm

See \gym_new_classic_envs\test_arm.py
