from setuptools import setup, find_packages
setup(name='gym_new_classic_envs', packages=find_packages())
# setup(name = 'gym_new_classic_envs', packages=find_packages(), version = '0.0.1', install_requires=['gym', 'numpy', 'matplotlib', 'scipy']) # And now install with: pip install -e .