"""Custom Pendulum Environment"""

from gym_new_classic_envs.envs.custom_pendulum.custom_pendulum import CustomPendulumEnv